<?php
session_start(); // Varmista, ett� sessio on aloitettu ennen muuta koodia

// Tarkista, ett� POST-data on l�hetetty
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Tarkista, onko kyseess� lainaaminen vai palauttaminen
    if (isset($_POST['action']) && $_POST['action'] === 'borrow') {
        // Lainaa kirja
        handleBorrow();
    } elseif (isset($_POST['action']) && $_POST['action'] === 'return') {
        // Palauta kirja
        handleReturn();
    }
}

function handleBorrow() {
    $kirjaId = intval($_POST['bookId']);
    $opiskelijaNumero = intval($_POST['studentId']);

    $conn = connectToDatabase();

    // Tarkista, onko kirja saatavilla
    $checkQuery = "SELECT maara FROM Kirja WHERE `kirja_id` = ?";
    $stmt = $conn->prepare($checkQuery);
    if (!$stmt) die("Virhe kyselyn valmistelussa: " . $conn->error);
    $stmt->bind_param("i", $kirjaId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $_SESSION['message'] = 'Kirjaa ei l�ydy.';
        $_SESSION['message_type'] = 'error';
        header("Location: koti.php");
        exit;
    }

    $row = $result->fetch_assoc();
    if ($row['maara'] <= 0) {
        $_SESSION['message'] = 'Kirjaa ei ole saatavilla.';
        $_SESSION['message_type'] = 'error';
        header("Location: koti.php");
        exit;
    }

    // P�ivit� kirjan m��r�
    $updateQuery = "UPDATE Kirja SET maara = maara - 1 WHERE `kirja_id` = ?";
    $stmt = $conn->prepare($updateQuery);
    if (!$stmt) die("Virhe kyselyn valmistelussa: " . $conn->error);
    $stmt->bind_param("i", $kirjaId);
    $stmt->execute();

    // Lis�� lainaustieto
    $insertQuery = "INSERT INTO lainaus (opiskelijanumero, kirja_id, lainausaika, kesto, palautusaika) 
                    VALUES (?, ?, NOW(), 14, NULL)";
    $stmt = $conn->prepare($insertQuery);
    if (!$stmt) die("Virhe kyselyn valmistelussa: " . $conn->error);
    $stmt->bind_param("ii", $opiskelijaNumero, $kirjaId);

    if ($stmt->execute()) {
        $_SESSION['message'] = 'Lainaus onnistui!';
        $_SESSION['message_type'] = 'success';
    } else {
        $_SESSION['message'] = 'Lainaustiedon tallennus ep�onnistui.';
        $_SESSION['message_type'] = 'error';
    }

    $conn->close();

    // Siirry takaisin koti-sivulle (Redirect After Post)
    header("Location: koti.php");
    exit;
}

function handleReturn() {
    $kirjaId = intval($_POST['bookId']);
    $opiskelijaNumero = intval($_POST['studentId']);

    $conn = connectToDatabase();

    // Tarkista, onko laina olemassa ja avoin (palautusaika IS NULL)
    $checkQuery = "SELECT lainaus_id FROM lainaus WHERE kirja_id = ? AND opiskelijanumero = ? AND palautusaika IS NULL LIMIT 1";
    $stmt = $conn->prepare($checkQuery);
    if (!$stmt) die("Virhe kyselyn valmistelussa: " . $conn->error);
    $stmt->bind_param("ii", $kirjaId, $opiskelijaNumero);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $_SESSION['message'] = 'Ei avoimia lainoja t�lle kirjalle ja opiskelijalle.';
        $conn->close();
        header("Location: koti.php");
        exit;
    }

    // Ota ensimm�inen avoin lainaus
    $row = $result->fetch_assoc();
    $lainausId = $row['lainaus_id'];

    // P�ivit� palautusaika
    $updateQuery = "UPDATE lainaus SET palautusaika = NOW() WHERE lainaus_id = ?";
    $stmt = $conn->prepare($updateQuery);
    if (!$stmt) die("Virhe kyselyn valmistelussa: " . $conn->error);
    $stmt->bind_param("i", $lainausId);
    $stmt->execute();

    // P�ivit� kirjan m��r�
    $updateBookQuery = "UPDATE Kirja SET maara = maara + 1 WHERE kirja_id = ?";
    $stmt = $conn->prepare($updateBookQuery);
    if (!$stmt) die("Virhe kyselyn valmistelussa: " . $conn->error);
    $stmt->bind_param("i", $kirjaId);
    $stmt->execute();

    $_SESSION['message'] = 'Kirja palautettu onnistuneesti!';
    $_SESSION['message_type'] = 'success';
    $conn->close();

    // Siirry takaisin koti-sivulle (Redirect After Post)
    header("Location: koti.php");
    exit;
}

function connectToDatabase() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "KirjastoDB";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Yhteys ep�onnistui: " . $conn->connect_error);
    }
    $conn->set_charset("utf8mb4");
    return $conn;
}

?>

<!DOCTYPE html>
<html lang="fi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kirjaston Lainauskone - Lomake</title>
    <link href="koti.css" rel="stylesheet">
</head>
<body>
    <header>
        <img src="logo.png" alt="Kirjaston logo" class="logo">
        <h1>Kirjaston Lainauskone</h1>
    </header>

    <?php
    if (isset($_SESSION['message'])): ?>
    <div class="message <?= $_SESSION['message_type']; ?>">
        <?= $_SESSION['message']; ?>
        <button class="close-btn" onclick="this.parentElement.style.display='none';">&times;</button>
    </div>
    <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <main>
        <section class="touch-interface">
            <h2>Selaa ja lainaa kirjoja</h2>
            <form action="" method="POST">
                <input type="hidden" name="action" value="borrow">
                <label for="bookId">Valitse kirja:</label>
                <select name="bookId" id="bookId" required>
                    <option value="">Valitse kirja</option>
                    <?php
                    $conn = connectToDatabase();
                    $sql = "SELECT * FROM Kirja";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<option value='" . htmlspecialchars($row['kirja_id']) . "'>" . htmlspecialchars($row['nimi'], ENT_QUOTES | ENT_HTML5, 'UTF-8') . "</option>";
                        }
                    } else {
                        echo "<option disabled>Ei kirjoja saatavilla</option>";
                    }
                    $conn->close();
                    ?>
                </select>

                <br><br>

                <label for="studentId">Opiskelijanumero (NFC):</label>
                <input type="text" name="studentId" id="studentId" required pattern="\d{6,10}" 
                       placeholder="Lue NFC-tunniste" readonly>

                <br><br>

                <input type="submit" value="Lainaa kirja">
            </form>

            <h2>Palauta kirja</h2>
            <form action="" method="POST">
                <input type="hidden" name="action" value="return">
                <label for="bookIdReturn">Valitse kirja:</label>
                <select name="bookId" id="bookIdReturn" required>
                    <option value="">Valitse kirja</option>
                    <?php
                    $conn = connectToDatabase();
                    $sql = "SELECT * FROM Kirja";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<option value='" . htmlspecialchars($row['kirja_id']) . "'>" . htmlspecialchars($row['nimi'], ENT_QUOTES | ENT_HTML5, 'UTF-8') . "</option>";
                        }
                    } else {
                        echo "<option disabled>Ei kirjoja saatavilla</option>";
                    }
                    $conn->close();
                    ?>
                </select>

                <br><br>

                <label for="studentIdReturn">Opiskelijanumero (NFC):</label>
                <input type="text" name="studentId" id="studentIdReturn" required pattern="\d{6,10}" 
                       placeholder="Lue NFC-tunniste" readonly>

                <br><br>

                <input type="submit" value="Palauta kirja">
            </form>
        </section>
    </main>

    <script>
  // Oletetaan, ett� NFC-lukija l�hett�� tiedon t�nne (Web NFC API)
  async function onNfcDataReceived(nfcData) {
    // T�ytet��n opiskelijanumero NFC-lukijalta saaduilla tiedoilla
    document.getElementById("UID").value = nfcData;
    document.getElementById("studentIdReturn").value = nfcData;
  }

  // Web NFC API:n k�ytt� (jos selain tukee sit�)
  async function startNfcReader() {
    // Tarkistetaan, tukevatko selaimet Web NFC:t�
    if ('NFC' in navigator) {
      try {
        const nfc = navigator.nfc;
        
        // Alustetaan lukija ja m��ritell��n tapahtuma, kun NFC-tunniste luetaan
        const reader = new NDEFReader();
        
        reader.onreading = event => {
          // Ota NFC-lukijan serialNumber (tai muu NFC-datan arvo)
          const nfcData = event.serialNumber; // Huomaa: tarkista, mit� tietoa saat
          onNfcDataReceived(nfcData);  // T�yt� lomake NFC-datalla
        };

        // Aloitetaan lukeminen
        await reader.scan();
      } catch (error) {
        console.error('NFC-lukeminen ep�onnistui:', error);
      }
    } else {
      console.log('Web NFC API ei ole tuettu t�ss� selaimessa');
    }
  }

  // K�ynnistet��n NFC-lukija
  startNfcReader();
</script>

</body>
</html>
